
Appendix D: Sample Packet decoding
==================================

|appendix chart1|

Figure 30 Example payload from Angle Data Packet 2 (A2)

|appendix chart2|

Figure 31 Example payload from Scaled Data Packet 1 (S1)

|appendix chart3|

Figure 32 Example payload from Nav Data Packet 1 (N1)

.. |appendix chart1| image:: media/image10.png
   :width: 5.49583in
   :height: 6.66944in
.. |appendix chart2| image:: media/image11.png
   :width: 5.49583in
   :height: 4.77361in
.. |appendix chart3| image:: media/image12.png
   :width: 5.50417in
   :height: 7.34792in
