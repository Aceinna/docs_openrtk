Appendix F: Python Example of Firmware Upgrade 
**********************************************

Download a python program from GitHub, https://github.com/Aceinna/python-imu380. 
Tap or click Windows Start button, then open Command Prompt. 

Firmware upgrade starts by a command “python upgrade_fw.py”.


|image45|


|image38|

.. |image45| image:: media/python.png
   :width: 5.66667in
   :height: 4.91042in
.. |image38| image:: media/python1.png
   :width: 5.66667in
   :height: 4.91042in
